# ResearchScribe 0.1.0

Apple Silicon Mac용 연구 강의·회의 기록 **소스 MVP**입니다. 원음 저장을 우선하며 ASR·로컬 번역·인용 기반 증분 요약·질문 GUI를 포함합니다. **M2 실기기에서 검증된 상용 품질의 앱이나 서명된 .app은 아닙니다.** 현재 Linux에서 핵심 로직 및 Qt GUI를 검증했고, 실제 마이크·MLX·Ollama 추론 검증은 별도입니다. 실험 결과를 대신하는 데모 전사는 제공하지 않습니다.

## 빠른 시작 — Mac에서

1. macOS Apple Silicon용 Python **3.11**을 설치합니다. Rosetta Python은 사용하지 마세요. Homebrew를 쓰는 경우:

   ```bash
   brew install python@3.11 portaudio ffmpeg
   ```

2. 이 폴더를 압축 해제한 위치에서 터미널을 열어 실행합니다.

   ```bash
   bash scripts/setup_mac.sh
   bash scripts/download_models.sh small
   ```

   첫 설치·모델 다운로드에는 인터넷과 여유 디스크 공간이 필요합니다. 녹음 중 자동 모델 다운로드는 차단합니다. 최초 모델 선택은 Whisper small입니다. **정확도 최우수라는 뜻은 아닙니다.** 8GB/16GB 어느 쪽도 실시간 가능 여부는 아직 측정하지 않았습니다.

3. 번역·요약을 사용하려면 [Ollama](https://ollama.com/download/mac)를 설치합니다. 이미 실행 중인 Ollama 앱을 종료한 뒤 별도 터미널에서 로컬 전용 서버를 시작합니다.

   ```bash
   bash scripts/start_local_ai.sh
   ```

   또 다른 터미널에서:

   ```bash
   ollama pull qwen3:1.7b
   ./Start.command
   ```

   Qwen3 1.7B는 시작용 후보입니다. 한국어 학술 번역 품질·속도·총 메모리는 미검증입니다. `설정`에서 `qwen3:0.6b / 1.7b / 4b / 8b`만 선택할 수 있습니다. 서버에서 해당 모델을 먼저 내려받아야 합니다. 8GB에서는 작은 ASR과 0.6B/1.7B를 먼저 비교하고, 메모리 압박이 생기면 번역·요약을 끄고 원음과 전사를 우선하세요. 16GB에서는 turbo 및 Qwen ASR 1.7B/로컬 LLM 4B도 **후보로** 비교하세요.

4. 입력 장치를 고르고 `새 녹음 시작`을 누릅니다. macOS의 마이크 권한 요청을 허용하세요. 터미널 실행에서는 Terminal/iTerm/Python 중 실제 요청 주체에 권한을 줘야 합니다. `시스템 설정 → 개인정보 보호 및 보안 → 마이크`를 확인하세요.

5. **중요 회의 전 2분 테스트:** 실제 발표 음원이 들어오는지 음량 게이지와 원음 재생으로 확인하고, 전사·번역·내보내기를 시험하세요. 이 버전은 실기기 검증 전입니다.

## 포함 기능과 범위

| 항목 | 구현 상태 |
|---|---|
| 녹음 | GUI·ASR와 별도 spawn 프로세스, native sample rate PCM16 저장, 1초마다 fsync |
| 청크 | 12초 창 / 2초 overlap, 마지막 짧은 구간 포함, 디스크 기반 SQLite 작업 |
| 전사 | MLX Whisper small/turbo/large-v3, Qwen3-ASR 0.6B/1.7B 어댑터 |
| 누락 대응 | 원음 우선 저장, 작업 3회 시도, 실패 표시/수동 재시도, 복구, 최종 별도 pass |
| VAD | 기본 OFF, 선택 WebRTC VAD 0–3; 양성 프레임 하나면 전체 청크 유지 |
| 번역 | localhost Ollama, 원문과 ID 대응, 이전 2청크 문맥, 용어 사전 |
| 요약 | 60초마다 새 발언을 인용 항목으로 누적, 원문 인용 검증, 원문 수정 시 요약 재생성 |
| 질문 | 최근 32청크에서만 인용 기반 답변. 전체 강의 검색은 후속 작업 |
| GUI | 한국어, 다크 테마, 4패널, 입력/모델/언어/모드 선택, 음량·대기시간·시스템 RAM |
| 원음 확인 | 행 선택 → 선택 원음 듣기. 원본 ASR은 행 툴팁과 JSON에 보존 |
| 내보내기 | WAV / JSON / Markdown, 원본 ASR·수정문·처리상태·요약·이벤트 포함 |
| 시스템 오디오 | 별도 설치한 BlackHole 입력, stereo 보존 후 ASR만 mono downmix |
| 미구현 | ScreenCaptureKit 직접 캡처, 마이크+시스템 동시 믹싱, 화자 분리, 문장/단어 정렬, 전체 기록 RAG |
| 클라우드 | GPT·Claude 전송 미구현. API 키를 입력하거나 저장하는 코드 없음 |
| 패키징 | 실험용 PyInstaller spec/script. 서명·공증·실기기 동작 미검증 |

**전사는 12초 안팎의 청크 단위 near-real-time 방식입니다.** 문장 단위 확정 스트리밍이나 동시통역 지연 보장은 아닙니다. 최소 창 대기 + 추론 + 큐 대기 시간이 걸립니다. 화면의 미처리 시간은 오디오 길이와 마지막 완료 청크 끝의 차이이며 정확한 발언별 latency가 아닙니다. 오류가 난 앞 구간은 처리상태/이벤트로 별도 확인하세요.

## 다른 모델 설치

```bash
bash scripts/download_models.sh turbo
bash scripts/download_models.sh large
bash scripts/download_models.sh qwen06
bash scripts/download_models.sh qwen17
```

Qwen 선택 시 `mlx-audio[stt]==0.4.8` 및 의존성을 추가 설치합니다. 배포 wheel의 `load()` / `generate(audio, language, system_prompt, max_tokens)` 인터페이스를 확인했지만 이 Linux 환경에서는 MLX를 실행하지 않았습니다. 설치된 의존성은 `installed-mac.txt`에 기록합니다. macOS 버전별 wheel 지원 여부는 설치 시 확인해야 합니다. 기본 Whisper 구성은 Qwen 관련 대형 의존성을 설치하지 않습니다.

## 폴더 구조

- `src/researchscribe/core.py`: 설정, 세션, SQLite, 청크 계획, 원음 읽기/내보내기
- `capture.py`: 녹음 프로세스 및 디스크 writer
- `asr.py`: 모델 어댑터, VAD, 중복 표시 병합, 재시도
- `ai.py`: 로컬 번역, 인용 검증, 증분 요약
- `gui.py`: 실제 PySide6 GUI와 프로세스 수명 관리
- `cli.py`: 모델 다운로드, WAV import 벤치마크, 복구/내보내기
- `scripts/`: 설치·실행·패키징·가속 저장 테스트
- `tests/`: 핵심/Qt 테스트
- `docs/RESEARCH.md`: 기술 조사와 선택 근거
- `docs/MAC_VALIDATION.md`: 실기기 평가 절차
- `docs/TEST_RESULTS.md`: 실제 검사 결과와 미검증 항목
- `config.example.json`: 세션 설정 예시

## 일상 사용 / 복구

- `일시정지`: 그 구간은 저장하지 않습니다. 이후 타임스탬프는 실제 벽시계가 아닌 **저장된 오디오 시간**입니다. pause/resume 시각은 이벤트에 기록합니다.
- `녹음 중지`: 원음 저장을 닫고 남은 전사·번역을 처리합니다. 요약은 60초 주기이므로 늦게 갱신될 수 있습니다. 정상 처리 종료 시 마지막 분도 처리합니다.
- `새 녹음`: 이전 AI 작업은 중단하고 새 세션을 만듭니다. 이전 미완료 작업은 이력에서 복구할 수 있습니다.
- `설정`: 녹음 중지 후 변경합니다. 진행 중인 AI는 중단되며, 해당 세션 설정은 바꾸지 않고 다음 새 세션에 적용합니다.
- `이전 기록 / 복구`: `~/Library/Application Support/ResearchScribe/` 아래 세션 폴더를 선택합니다. 디스크에 남은 PCM 길이로 작업을 복구합니다. **동일 세션을 여러 앱/CLI에서 동시에 처리하지 마세요.**
- `실패 재시도`: 모델 설치/서버 오류를 해결한 뒤 클릭합니다. running 상태는 재시작 시 pending으로 복구합니다.
- 원문 더블클릭: 수정문을 저장하고 해당 번역과 요약을 무효화합니다. 최초 ASR 텍스트는 덮어쓰지 않습니다. 병합 전 ASR 결과는 툴팁/내보낸 JSON의 `raw`입니다.
- `최종 재전사`: 같은 세션 모델로 전체 원음을 별도 `final-HHMMSS` pass에 재전사합니다. **자동 고정밀 보정이나 정확도 향상을 보장하지 않습니다.** 과거 live pass는 보존됩니다. 과거 pass 선택 UI는 후속 작업이며 CLI `export --pass-name`으로 접근할 수 있습니다.
- `선택 원음 듣기`: 헤드폰을 사용하세요. 녹음 중 스피커 재생은 마이크에 재유입될 수 있습니다.
- 창 종료: 녹음을 먼저 flush/종료하며, AI는 제한 시간 후 중단합니다. 미완료 AI는 복구 대상입니다. 강제 종료·정전은 마지막 fsync 이후 데이터 또는 콜백 큐의 일부를 잃을 수 있습니다. 무손실 보장은 아닙니다.

## 시스템 오디오 — BlackHole 방식

[BlackHole 공식 설명](https://github.com/ExistentialAudio/BlackHole)에 따라 2ch 장치를 설치하세요. macOS `오디오 MIDI 설정`에서 스피커/헤드폰과 BlackHole을 포함하는 다중 출력 장치를 만들고 시스템 출력을 그 장치로 바꾼 후, ResearchScribe 입력으로 BlackHole을 고릅니다. 음량 미터와 녹음 내보내기로 채널을 확인하세요. 이 MVP는 마이크와 BlackHole을 동시에 녹음하지 않습니다. 직접 ScreenCaptureKit 캡처와 해당 권한은 미구현입니다.

## 벤치마크 / 테스트

```bash
.venv/bin/python -m pytest -q
.venv/bin/python scripts/soak_storage.py --minutes 10
.venv/bin/python scripts/soak_storage.py --minutes 30
.venv/bin/python scripts/soak_storage.py --minutes 60
```

위 저장 테스트는 **시간을 가속한 합성 PCM 검사**이며 실제 마이크·ASR·60분 발열 시험이 아닙니다.

권한 있는 동일 강의 음성과 사람이 확인한 정답 전사문을 준비하세요. 변환 후 그 파일을 모든 모델에 동일하게 사용합니다.

```bash
ffmpeg -i lecture.m4a -ac 1 -ar 16000 -c:a pcm_s16le lecture16.wav
.venv/bin/researchscribe-cli benchmark lecture16.wav --reference reference.txt --model small --output bench
.venv/bin/researchscribe-cli benchmark lecture16.wav --reference reference.txt --model turbo --output bench
.venv/bin/researchscribe-cli benchmark lecture16.wav --reference reference.txt --model qwen06 --output bench
.venv/bin/researchscribe-cli benchmark lecture16.wav --reference reference.txt --model qwen17 --output bench
.venv/bin/python -m pip install -e '.[vad]'
.venv/bin/researchscribe-cli benchmark lecture16.wav --reference reference.txt --model turbo --vad --vad-mode 0 --output bench
```

각 실행은 새 프로세스에서 실행합니다. 입력 SHA256, WER/CER, deletion rate, RTF, 청크 추론 시간, CPU와 프로세스 RSS 표본을 JSON에 저장합니다. 정답이 없으면 WER/CER를 만들지 않습니다. 실패 청크가 있으면 `valid:false`, exit 2이고 WER를 기록하지 않습니다. reference는 lowercase+공백 정리만 적용합니다. 한국어 WER는 띄어쓰기에 민감하므로 CER도 함께 봐야 합니다. `deletion_rate`는 발언 단위 누락률이 아닙니다. GPU 메모리, 동시 번역 지연, 발언별 누락률은 별도 계측이 필요합니다. 자세한 절차는 `docs/MAC_VALIDATION.md`를 읽으세요.

```bash
.venv/bin/researchscribe-cli recover '/세션/절대경로'
.venv/bin/researchscribe-cli export '/세션/절대경로' '/내보낼/폴더'
# 특정 재전사 pass 보존 결과:
.venv/bin/researchscribe-cli export '/세션/절대경로' '/내보낼/폴더' --pass-name final-123456
```

세션/PCM을 삭제하기 전에 내보낸 WAV가 재생되는지 확인하세요. 백업 시 앱과 작업을 종료하고 세션 폴더 전체를 복사하세요. SQLite WAL이 실행 중일 수 있으므로 DB 파일 하나만 복사하면 안 됩니다.

## 전문 용어·수치·개인정보

용어 사전은 ASR 힌트와 번역 프롬프트이며 인식 정확도를 보장하지 않습니다. 모델·논문 이름을 규칙으로 강제 치환하지 않습니다. 숫자, 단위, 원자 좌표, 화학식은 원음과 슬라이드로 검토하세요. 인용 검사도 텍스트 존재만 확인하며 의미상 사실성·ASR 자체의 정확성을 보증하지 않습니다. 작은 로컬 LLM의 한/영 번역·숫자 보존은 별도 평가해야 합니다.

앱은 외부 ASR/LLM 엔드포인트를 제공하지 않습니다. 모델 다운로드는 외부 서버와 통신하지만 음성/전사문을 올리지 않습니다. 번역·요약은 고정된 `127.0.0.1` Ollama에만 보내고 프록시/리다이렉트를 사용하지 않으며 remote 모델 정보를 거부합니다. Ollama 자체도 `start_local_ai.sh`의 `OLLAMA_NO_CLOUD=1`로 실행하세요. 향후 GPT·Claude 연동은 전송 범위와 비용을 보여주는 세션별 동의 및 Keychain 저장부터 구현해야 합니다. 이 버전에는 API 키가 없습니다.

파일은 기본 로컬 저장이며 암호화 기능은 별도 구현하지 않았습니다. FileVault와 기관 저장정책을 적용하세요. 녹음·외부 AI 활용 가능 여부는 참석자 동의와 소속기관 규정을 확인하세요. 이 문서는 법률 검토를 대신하지 않습니다.

## 실험용 .app 빌드

```bash
bash scripts/package_mac.sh
```

`dist/ResearchScribe.app`를 만들기 위한 스크립트입니다. **실제로 빌드/서명/공증한 .app을 제공하는 것은 아닙니다.** MLX Metal 라이브러리 포함, 마이크 권한, subprocess spawn, PyInstaller hook, Gatekeeper는 Mac에서 검증하세요. 모델은 번들에 포함하지 않고 먼저 다운로드합니다. `mlx-audio`의 선택적 torch 의존 기능은 번들에서 제외되므로 Qwen 어댑터도 별도 시험이 필요합니다. 우선 Python 환경에서 안정성을 검증한 뒤 패키징하세요.
