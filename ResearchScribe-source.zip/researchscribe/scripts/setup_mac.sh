#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin || "$(uname -m)" != arm64 ]]; then
  echo 'Apple Silicon macOS with native arm64 Python required.'; exit 1
fi
PYTHON_BIN="${PYTHON_BIN:-python3.11}"
"$PYTHON_BIN" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -e '.[mac,test]'
.venv/bin/python -m pip freeze > installed-mac.txt
printf '\nInstall models explicitly: scripts/download_models.sh small\n'
