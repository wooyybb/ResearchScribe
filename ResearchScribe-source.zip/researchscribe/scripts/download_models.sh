#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Installs dependencies/weights only. No audio or transcript upload.
if [[ "${1:-small}" == qwen* ]]; then
  .venv/bin/python -m pip install -e '.[qwen]'
fi
.venv/bin/researchscribe-cli download --model "${1:-small}"
if [[ "${2:-}" == '--llm' ]]; then
  ollama pull qwen3:1.7b
fi
