"""Actual Qt widgets, offscreen; does not validate macOS permissions or audio."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import json
import tempfile
import unittest
from PySide6 import QtWidgets
from researchscribe.gui import Window
from researchscribe.core import Config, create_session, connect

class GuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    def test_render_session_translation_and_evidence(self):
        with tempfile.TemporaryDirectory() as root:
            path=create_session(Config(ai_enabled=False),root=root)
            with connect(path) as db:
                db.execute("INSERT INTO chunks(pass,start,end,status,raw,text,translation,translation_status) VALUES('live',0,12,'done','Input is noisy STEM.','Input is noisy STEM.','입력은 noisy STEM입니다.','done')")
                db.execute("INSERT INTO notes(kind,content,created) VALUES('summary:live',?,0)",
                  (json.dumps({'claims':[{'source_id':1,'text':'입력은 STEM 영상','quote':'noisy STEM'}],'scope':'TEST fixture'}),))
            w=Window(); w.path=path; w.refresh(); w.show(); self.app.processEvents()
            self.assertEqual(w.transcript.rowCount(),1)
            self.assertIn('noisy STEM',w.translation.toPlainText())
            self.assertIn('[#1]',w.summary.toPlainText()); w.close()
