"""Model downloads from the desktop UI; no terminal needed."""
from PySide6 import QtCore, QtWidgets
from .cli import MODELS

class Download(QtCore.QThread):
    result=QtCore.Signal(bool,str)
    def __init__(self,model):
        super().__init__(); self.model=model
    def run(self):
        try:
            from huggingface_hub import snapshot_download
            path=snapshot_download(self.model)
            self.result.emit(True,'설치 완료: '+path)
        except Exception as e: self.result.emit(False,'설치 실패. 인터넷과 저장 공간을 확인한 뒤 다시 시도하세요.\n'+str(e))

class ModelSetup(QtWidgets.QDialog):
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('음성 인식 모델 설치'); self.resize(560,260); self.worker=None
        box=QtWidgets.QVBoxLayout(self)
        label=QtWidgets.QLabel('처음 한 번 모델을 다운로드합니다. 음성·전사문은 업로드하지 않습니다.\n설치 후에는 오프라인으로 인식할 수 있습니다.'); label.setWordWrap(True); box.addWidget(label)
        self.models=QtWidgets.QComboBox()
        for key,(_,repo) in MODELS.items(): self.models.addItem(key+' — '+repo,repo)
        box.addWidget(self.models)
        self.status=QtWidgets.QLabel('모델 크기에 따라 다운로드에 시간이 걸립니다.'); self.status.setWordWrap(True); box.addWidget(self.status)
        self.progress=QtWidgets.QProgressBar(); self.progress.setRange(0,1); box.addWidget(self.progress)
        self.start=QtWidgets.QPushButton('다운로드 및 설치'); self.start.clicked.connect(self.download); box.addWidget(self.start)
        self.done=QtWidgets.QPushButton('닫기'); self.done.clicked.connect(self.accept); box.addWidget(self.done)
    def download(self):
        self.start.setEnabled(False); self.done.setEnabled(False); self.models.setEnabled(False)
        self.progress.setRange(0,0); self.status.setText('다운로드 중…')
        self.worker=Download(self.models.currentData()); self.worker.result.connect(self.complete); self.worker.start()
    def complete(self,ok,message):
        self.status.setText(message); self.progress.setRange(0,1); self.progress.setValue(int(ok))
        self.start.setEnabled(True); self.done.setEnabled(True); self.models.setEnabled(True)
    def reject(self):
        if self.worker and self.worker.isRunning(): return
        super().reject()
    def closeEvent(self,event):
        if self.worker and self.worker.isRunning(): event.ignore()
        else: event.accept()
