#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x .venv/bin/researchscribe ]]; then
 echo '먼저 터미널에서 bash scripts/setup_mac.sh 를 실행하세요.'; exit 1
fi
exec .venv/bin/researchscribe
