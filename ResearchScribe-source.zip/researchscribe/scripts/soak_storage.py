"""Accelerated synthetic storage/scheduler test. NOT a real-time microphone/ASR test."""
import argparse
import hashlib
import json
import tempfile
import time
from pathlib import Path
import numpy as np
from researchscribe.core import Config, create_session, plan, connect, export_session

def main():
    p=argparse.ArgumentParser(); p.add_argument('--minutes',type=int,choices=[10,30,60],default=60); a=p.parse_args()
    begin=time.monotonic()
    with tempfile.TemporaryDirectory() as temp:
        path=create_session(Config(),16000,temp)
        rng=np.random.default_rng(42); block=rng.integers(-32768,32767,16000,dtype='<i2').tobytes()
        original=hashlib.sha256()
        with (path/'audio.pcm').open('ab',buffering=0) as out:
            for second in range(a.minutes*60):
                out.write(block); original.update(block)
                if second%10==0: plan(path)
        plan(path,complete=True); plan(path,complete=True)
        with connect(path) as db:
            rows=db.execute('SELECT start,end FROM chunks ORDER BY start').fetchall()
        assert rows[0][0]==0 and rows[-1][1]==a.minutes*60
        assert all(b[0]<=a[1] for a,b in zip(rows,rows[1:]))
        with (path/'audio.pcm').open('rb') as f: assert hashlib.file_digest(f,'sha256').digest()==original.digest()
        export_session(path,Path(temp)/'export')
        print(json.dumps({'test':'accelerated synthetic disk/scheduler','audio_minutes':a.minutes,
          'chunks':len(rows),'sample_coverage':'complete','raw_hash':'matches',
          'elapsed_seconds':time.monotonic()-begin,'microphone':False,'ASR':False,'real_time':False}))
if __name__=='__main__': main()
