import json
import multiprocessing as mp
import time
from pathlib import Path
from PySide6 import QtCore, QtWidgets, QtGui
from .core import ROOT, Config, create_session, connect, duration, export_session, config_for, event, read_audio, atomic_json
from .capture import capture
from .asr import run_asr
from .ai import run_ai, LocalAI, grounded

class Query(QtCore.QThread):
    result=QtCore.Signal(str)
    def __init__(self,path,question,pass_name):
        super().__init__(); self.path=path; self.question=question; self.pass_name=pass_name
    def run(self):
        try:
            with connect(self.path) as db:
                rows=db.execute("SELECT * FROM chunks WHERE pass=? AND status='done' ORDER BY start DESC LIMIT 32",(self.pass_name,)).fetchall()[::-1]
            claims=grounded(LocalAI(config_for(self.path).llm_model),rows,self.question)
            text='\n\n'.join(f"{c['text']} [#{c['source_id']}]\n근거: {c['quote']}" for c in claims)
            self.result.emit((text or '해당 범위에 확인 가능한 발언이 없습니다.')+'\n\n검색 범위: 최근 32개 청크. 이전 구간은 내보낸 원문을 확인하세요. 인용 일치는 의미의 정확성을 보증하지 않습니다.')
        except Exception as e: self.result.emit('AI 오류: '+str(e))

class Window(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('ResearchScribe · 연구 강의 기록'); self.resize(1390,880)
        self.ctx=mp.get_context('spawn'); self.path=None; self.cap=None; self.asr=None; self.ai=None; self.query=None; self.pass_name='live'; self.stopping=False
        base=QtWidgets.QWidget(); self.setCentralWidget(base); layout=QtWidgets.QVBoxLayout(base)
        top=QtWidgets.QHBoxLayout(); layout.addLayout(top)
        self.devices=QtWidgets.QComboBox(); self.refresh_devices(); top.addWidget(self.devices,2)
        self.model=QtWidgets.QComboBox()
        self.model.addItems(['Whisper small · 초기 설정','Whisper large-v3-turbo · 비교 후보','Whisper large-v3 · 비교 후보','Qwen3-ASR 0.6B · 비교 후보','Qwen3-ASR 1.7B · 비교 후보']); top.addWidget(self.model,2)
        self.language=QtWidgets.QComboBox(); self.language.addItems(['영어','한국어','자동']); top.addWidget(self.language)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(['강의','회의']); top.addWidget(self.mode)
        controls=QtWidgets.QHBoxLayout(); layout.addLayout(controls)
        self.start_btn=self.button('새 녹음 시작',self.start,controls)
        self.pause_btn=self.button('일시정지 / 재개',self.toggle_pause,controls)
        self.stop_btn=self.button('녹음 중지',self.stop,controls)
        self.button('이전 기록 / 복구',self.history,controls)
        self.button('실패 재시도',self.retry,controls)
        self.button('최종 재전사',self.final_pass,controls)
        self.button('선택 원음 듣기',self.play,controls)
        self.button('내보내기',self.export,controls)
        self.button('설정',self.settings,controls)
        self.button('모델 설치',self.install_models,controls)
        self.state=QtWidgets.QLabel('입력 선택 → 시작. 시스템 오디오는 BlackHole 장치가 필요합니다.'); layout.addWidget(self.state)
        self.level=QtWidgets.QProgressBar(); self.level.setRange(0,100); self.level.setMaximumHeight(12); layout.addWidget(self.level)
        grid=QtWidgets.QGridLayout(); layout.addLayout(grid,1)
        self.transcript=QtWidgets.QTableWidget(0,3); self.transcript.setHorizontalHeaderLabels(['ID','오디오 시간','원문 · 더블클릭하여 수정'])
        self.transcript.horizontalHeader().setStretchLastSection(True); self.transcript.setWordWrap(True)
        self.transcript.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.transcript.cellDoubleClicked.connect(self.edit)
        self.translation=QtWidgets.QTextBrowser(); self.summary=QtWidgets.QTextBrowser(); self.answer=QtWidgets.QTextBrowser()
        for widget,title,row,col in [(self.transcript,'A · 전사 초안 / 원음 확인 필요',0,0),(self.translation,'B · 한국어 번역',0,1),(self.summary,'C · 증분 요약 · 60초 간격',1,0),(self.answer,'D · 원문에 질문',1,1)]:
            box=QtWidgets.QGroupBox(title); b=QtWidgets.QVBoxLayout(box); b.addWidget(widget); grid.addWidget(box,row,col)
        bottom=QtWidgets.QHBoxLayout(); layout.addLayout(bottom)
        self.question=QtWidgets.QLineEdit(); self.question.setPlaceholderText('이 연구의 Input과 Output은? (최근 32개 청크 검색)'); bottom.addWidget(self.question)
        self.ask_btn=self.button('AI 질문',self.ask,bottom)
        self.terms=Config().terms; self.llm='qwen3:1.7b'; self.ai_enabled=True; self.auto_scroll=True
        try:
            saved=json.loads((ROOT/'settings.json').read_text())
            self.terms=saved['terms']; self.llm=saved['llm']; self.ai_enabled=saved['ai_enabled']
            self.model.setCurrentIndex(saved['model']); self.language.setCurrentIndex(saved['language']); self.mode.setCurrentIndex(saved['mode'])
        except (OSError,KeyError,ValueError): pass
        self.timer=QtCore.QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(1000)
        self.refresh()
    def button(self,label,fn,layout):
        b=QtWidgets.QPushButton(label); b.clicked.connect(fn); layout.addWidget(b); return b
    def refresh_devices(self):
        try:
            import sounddevice as sd
            self.devices.addItem('기본 마이크',None)
            for i,d in enumerate(sd.query_devices()):
                if d['max_input_channels']>0: self.devices.addItem(f"{i}: {d['name']}",i)
        except Exception as e: self.devices.addItem('오디오 장치 오류: '+str(e),None)
    def error(self,e): QtWidgets.QMessageBox.warning(self,'ResearchScribe',str(e))
    def active(self):
        return any(p is not None and p.is_alive() for p in (self.cap,self.asr,self.ai))
    def make_config(self):
        models=[('whisper','mlx-community/whisper-small-mlx'),('whisper','mlx-community/whisper-large-v3-turbo'),('whisper','mlx-community/whisper-large-v3-mlx'),('qwen','mlx-community/Qwen3-ASR-0.6B-8bit'),('qwen','mlx-community/Qwen3-ASR-1.7B-8bit')]
        backend,model=models[self.model.currentIndex()]
        return Config(backend=backend,model=model,language=['en','ko','auto'][self.language.currentIndex()],terms=self.terms,llm_model=self.llm,mode=['lecture','meeting'][self.mode.currentIndex()],ai_enabled=self.ai_enabled)
    def launch_workers(self,complete=False):
        self.finish=self.ctx.Event(); self.cancel=self.ctx.Event(); self.ai_cancel=self.ctx.Event()
        if complete: self.finish.set()
        self.asr=self.ctx.Process(target=run_asr,args=(str(self.path),self.finish,self.cancel,self.pass_name)); self.asr.start()
        if config_for(self.path).ai_enabled:
            self.ai=self.ctx.Process(target=run_ai,args=(str(self.path),self.ai_cancel,self.pass_name)); self.ai.start()
    def start(self):
        if self.cap and self.cap.is_alive(): return
        self.shutdown_workers()
        try:
            import sounddevice as sd
            device=self.devices.currentData(); rate=round(sd.query_devices(device,'input')['default_samplerate'])
            channels=2 if 'blackhole' in self.devices.currentText().lower() else 1
            sd.check_input_settings(device=device,channels=channels,dtype='int16',samplerate=rate)
            self.path=create_session(self.make_config(),rate,channels=channels); self.pass_name='live'; self.stopping=False
            self.cap_stop=self.ctx.Event(); self.pause=self.ctx.Event()
            self.cap=self.ctx.Process(target=capture,args=(str(self.path),device,self.cap_stop,self.pause)); self.cap.start()
            self.launch_workers(); self.state.setText('녹음 시작 중… '+str(self.path))
        except Exception as e: self.error(e)
    def toggle_pause(self):
        if self.cap is not None and self.cap.is_alive():
            if self.pause.is_set(): self.pause.clear(); action='resume'
            else: self.pause.set(); action='pause'
            event(self.path,action,'일시정지 구간은 녹음되지 않음; 시간은 오디오 기준')
    def stop(self):
        if self.cap is not None and self.cap.is_alive():
            self.cap_stop.set(); self.stopping=True
        elif self.asr is not None:
            self.finish.set()
    def shutdown_workers(self):
        if hasattr(self,'cancel'): self.cancel.set()
        if hasattr(self,'ai_cancel'): self.ai_cancel.set()
        for p in (self.asr,self.ai):
            if p is not None:
                p.join(.5)
                if p.is_alive(): p.terminate(); p.join(2)
        self.asr=None; self.ai=None
    def history(self):
        if self.cap is not None and self.cap.is_alive(): return self.error('녹음을 먼저 중지하세요.')
        path=QtWidgets.QFileDialog.getExistingDirectory(self,'세션 폴더 선택',str(ROOT))
        if not path: return
        if not (Path(path)/'audio.pcm').is_file(): return self.error('세션 폴더가 아닙니다.')
        self.shutdown_workers(); self.path=Path(path); self.pass_name='live'; self.cap=None; self.stopping=False
        c=config_for(self.path); self.terms=c.terms; self.llm=c.llm_model
        event(self.path,'recovery','오디오 파일 길이에서 작업 복구')
        self.launch_workers(complete=True); self.refresh()
    def retry(self):
        if self.path is None: return
        with connect(self.path) as db:
            db.execute("UPDATE chunks SET status='pending',attempts=0 WHERE status='failed'")
            db.execute("DELETE FROM notes WHERE kind LIKE 'summary:%'")
            db.execute('INSERT INTO events(at,kind,detail) VALUES(?,?,?)',(time.time(),'edit','Retry invalidated derived summaries'))
            db.execute("UPDATE chunks SET translation_status='pending',translation_attempts=0 WHERE translation_status='failed'")
        if self.asr is None or not self.asr.is_alive():
            self.shutdown_workers(); self.launch_workers(complete=not(self.cap and self.cap.is_alive()))
    def final_pass(self):
        if not self.path: return
        if self.cap and self.cap.is_alive(): return self.error('녹음 중지 후 실행하세요.')
        self.shutdown_workers(); self.pass_name='final-'+time.strftime('%H%M%S'); self.launch_workers(complete=True)
        event(self.path,'final_pass',self.pass_name)
    def play(self):
        if not self.path: return
        row=self.transcript.currentRow()
        if row<0: return
        try:
            import sounddevice as sd
            id=int(self.transcript.item(row,0).text())
            with connect(self.path) as db: r=db.execute('SELECT start,end FROM chunks WHERE id=?',(id,)).fetchone()
            sd.play(read_audio(self.path,r['start'],r['end']),16000)
        except Exception as e: self.error(e)
    def export(self):
        if self.path is None: return
        target=QtWidgets.QFileDialog.getExistingDirectory(self,'내보낼 폴더 선택')
        if target:
            try: export_session(self.path,Path(target)/self.path.name,self.pass_name)
            except Exception as e: self.error(e)
    def edit(self,row,col):
        if not self.path: return
        id=int(self.transcript.item(row,0).text())
        old=self.transcript.item(row,2).text()
        text,ok=QtWidgets.QInputDialog.getMultiLineText(self,'원문 수정','원본 ASR은 별도 보존됩니다.',old)
        if ok:
            with connect(self.path) as db:
                db.execute("UPDATE chunks SET edited=?,translation=NULL,translation_status='pending',translation_attempts=0 WHERE id=?",(text,id))
                # Old evidence can be stale. Invalidate derived summary; rebuild incrementally.
                db.execute("DELETE FROM notes WHERE kind=?",('summary:'+self.pass_name,))
                db.execute('INSERT INTO events(at,kind,detail) VALUES(?,?,?)',(time.time(),'edit',json.dumps({'id':id,'before':old,'after':text},ensure_ascii=False)))
    def install_models(self):
        from .setup_ui import ModelSetup
        dialog=ModelSetup(self); dialog.exec()
    def settings(self):
        if self.cap and self.cap.is_alive(): return self.error('녹음 중지 후 설정을 변경하세요.')
        self.shutdown_workers()
        dialog=QtWidgets.QDialog(self); dialog.setWindowTitle('로컬 AI 설정'); form=QtWidgets.QFormLayout(dialog)
        terms=QtWidgets.QPlainTextEdit(self.terms); form.addRow('전문 용어 / 모델 이름',terms)
        llm=QtWidgets.QLineEdit(self.llm); form.addRow('Ollama 모델',llm)
        ai=QtWidgets.QCheckBox('번역·요약 사용 (127.0.0.1 Ollama)'); ai.setChecked(self.ai_enabled); form.addRow(ai)
        scroll=QtWidgets.QCheckBox('원문 자동 스크롤'); scroll.setChecked(self.auto_scroll); form.addRow(scroll)
        form.addRow(QtWidgets.QLabel('클라우드 API: 이 버전 미구현. 외부 전사문 전송 없음.\nVAD 기본 OFF. 실험은 CLI 설정으로 수행하세요.'))
        buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Ok|QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); form.addRow(buttons)
        if dialog.exec():
            self.terms=terms.toPlainText(); self.llm=llm.text(); self.ai_enabled=ai.isChecked(); self.auto_scroll=scroll.isChecked()
            ROOT.mkdir(parents=True,exist_ok=True,mode=0o700)
            atomic_json(ROOT/'settings.json',{'terms':self.terms,'llm':self.llm,'ai_enabled':self.ai_enabled,
                'model':self.model.currentIndex(),'language':self.language.currentIndex(),'mode':self.mode.currentIndex()})
    def ask(self):
        if not self.path or (self.query and self.query.isRunning()): return
        self.ask_btn.setEnabled(False); self.answer.setPlainText('로컬 AI 처리 중…')
        self.query=Query(self.path,self.question.text(),self.pass_name)
        self.query.result.connect(self.answer.setPlainText); self.query.finished.connect(lambda:self.ask_btn.setEnabled(True)); self.query.start()
    def refresh(self):
        import psutil
        live=self.cap is not None and self.cap.is_alive()
        self.start_btn.setEnabled(not self.active()); self.pause_btn.setEnabled(live); self.stop_btn.setEnabled(live)
        if not self.path: return
        try:
            if not live and hasattr(self,'finish'): self.finish.set()
            with connect(self.path) as db:
                rows=db.execute('SELECT * FROM chunks WHERE pass=? ORDER BY start DESC LIMIT 300',(self.pass_name,)).fetchall()[::-1]
                stats=db.execute("SELECT status,COUNT(*) FROM chunks WHERE pass=? GROUP BY status",(self.pass_name,)).fetchall()
                last=db.execute("SELECT content FROM notes WHERE kind=? ORDER BY id DESC LIMIT 1",('summary:'+self.pass_name,)).fetchone()
                done=db.execute("SELECT MAX(end) FROM chunks WHERE pass=? AND status='done'",(self.pass_name,)).fetchone()[0] or 0
            current=json.loads((self.path/'capture.json').read_text())
            self.level.setValue(min(100,int(current['rms']*300)))
            ram=psutil.virtual_memory()
            warning=(self.path/'warning.json')
            warning_text=json.loads(warning.read_text())['message'] if warning.exists() else ''
            with connect(self.path) as db:
                recent=db.execute("SELECT detail FROM events WHERE kind LIKE '%error' ORDER BY id DESC LIMIT 1").fetchone()
            if recent: warning_text+=' '+recent[0][:150]
            asr_state='실행' if self.asr and self.asr.is_alive() else '종료 (오류 시 events 확인)'
            self.state.setText(f"{self.path.name} · {self.pass_name} · 녹음 {current['state']} · {duration(self.path):.0f}초 · ASR {asr_state} · 미처리 시간 {max(0,duration(self.path)-done):.0f}초 · RAM {ram.percent}% · {dict(stats)} {warning_text}")
            self.transcript.setRowCount(len(rows))
            translated=[]
            for i,r in enumerate(rows):
                text=r['edited'] if r['edited'] is not None else r['text']
                for j,v in enumerate((r['id'],f"{r['start']:.1f}–{r['end']:.1f}",text if r['status']=='done' else f"{r['status']}: {r['error'] or ''}")):
                    item=QtWidgets.QTableWidgetItem(str(v))
                    item.setToolTip('원본 ASR (병합 전): '+r['raw']); self.transcript.setItem(i,j,item)
                translated.append(f"[#{r['id']}] {r['translation'] or r['translation_status']}")
            self.transcript.resizeRowsToContents()
            if self.auto_scroll: self.transcript.scrollToBottom()
            self.translation.setPlainText('\n\n'.join(translated))
            if last:
                data=json.loads(last[0]); self.summary.setPlainText('\n\n'.join(f"{c['text']} [#{c['source_id']}]\n근거: {c['quote']}" for c in data['claims'][-150:])+'\n\n'+data['scope'])
            else: self.summary.setPlainText('로컬 요약 대기 · 인용할 발언이 없으면 요약하지 않습니다.')
            if not live and self.asr and not self.asr.is_alive() and self.ai:
                # Allow translation backlog to drain; then release AI process automatically.
                with connect(self.path) as db:
                    pending=db.execute("SELECT COUNT(*) FROM chunks WHERE pass=? AND status='done' AND translation_status='pending'",(self.pass_name,)).fetchone()[0]
                if pending==0: self.ai_cancel.set()
        except Exception as e: self.state.setText('상태 읽기 오류: '+str(e))
    def closeEvent(self, ev):
        if self.query and self.query.isRunning():
            self.error('AI 질문 처리 중입니다. 완료 후 종료하세요.'); ev.ignore(); return
        if self.cap and self.cap.is_alive():
            self.cap_stop.set(); self.cap.join(5)
            if self.cap.is_alive():
                self.error('오디오 저장 중입니다. 잠시 후 다시 닫으세요.'); ev.ignore(); return
        self.shutdown_workers(); ev.accept()

def main():
    mp.freeze_support()
    app=QtWidgets.QApplication([]); app.setStyle('Fusion')
    palette=QtGui.QPalette(); palette.setColor(QtGui.QPalette.ColorRole.Window,QtGui.QColor('#17212b'))
    palette.setColor(QtGui.QPalette.ColorRole.WindowText,QtGui.QColor('#edf2f7'))
    palette.setColor(QtGui.QPalette.ColorRole.Base,QtGui.QColor('#0f1720'))
    palette.setColor(QtGui.QPalette.ColorRole.Text,QtGui.QColor('#edf2f7'))
    palette.setColor(QtGui.QPalette.ColorRole.Button,QtGui.QColor('#263749'))
    palette.setColor(QtGui.QPalette.ColorRole.ButtonText,QtGui.QColor('#edf2f7')); app.setPalette(palette)
    w=Window(); w.show(); app.exec()

if __name__=='__main__': main()
