# 실제 검사 결과 — 2026-11-10

## 환경

Linux x86_64, Python 3.12.14. Apple Silicon Mac이 아니다. 모델 가중치와 실제 강연 정답 음원이 제공되지 않았다. PortAudio 시스템 라이브러리가 이 환경에 없어 실제 오디오 장치는 열지 않았다. PySide6는 설치했으며 offscreen Qt로 실제 Window 클래스의 위젯과 데이터 연결을 검사했다.

## 실행한 검사

| 검사 | 실제 결과 | 증명하지 않는 것 |
|---|---|---|
| `python -m pytest -q researchscribe/tests` | **17 passed**, 최종 실행 7.13초. 외부 pytest plugin deprecation 경고 1건 | macOS 마이크·MLX 추론 성공 |
| Qt GUI | offscreen Window 표시, 95 위젯 생성, 원문/번역/인용 데이터 연결 검사 통과 | macOS Retina, TCC 권한, 실시간 입력 |
| Python compileall | 통과 | 모든 선택 의존성의 Mac 런타임 성공 |
| bash syntax / CLI help | 통과 | Mac 설치·.app 빌드 성공 |
| pip check | 현재 Linux 기본/test 환경의 깨진 의존성 없음 | mac/qwen extra 설치 성공 |
| Qwen MLX 배포 API 정적 확인 | `mlx-audio 0.4.8` wheel의 load/generate와 numpy 입력 지원 확인 | 모델 출력·정확도·Metal 동작 |
| 10분 분량 가속 저장 | 60청크, 전체 구간 coverage, 원본 SHA256 일치 | 실제 10분 마이크 녹음 |
| 30분 분량 가속 저장 | 180청크, 전체 구간 coverage, 원본 SHA256 일치 | 실제 30분 추론·발열 |
| 60분 분량 가속 저장 | 360청크, 전체 구간 coverage, 원본 SHA256 일치 | 실제 60분 실시간 녹음·추론 |

원본 로그는 `validation/pytest.txt`, `validation/storage10.json`, `storage30.json`, `storage60.json`에 포함되어 있다. 가속 저장 검사는 같은 합성 PCM 블록을 디스크에 쓰는 검사이며 노이즈를 음성처럼 인식시키지 않는다.

17개 테스트에는 경계/마지막 짧은 창 coverage, 반복 계획 idempotence, live/final 분리, 원본 ASR 보존, 보수적 중복 표시 병합, 3회 재시도/실패, 부분 샘플을 제외한 WAV 내보내기, resampling, 유효 인용과 조작 인용 구분, VAD OFF의 호출/ON 무음 skip 시 원음 보존, 콜백을 대체한 녹음 writer의 스테레오 queue drain, cloud 모델 거부, 실제 Qt 데이터 표시, benchmark 점수/실패 결과 로직 검사가 포함된다.

**테스트용 ASR 대체 객체가 내는 고정 텍스트의 WER=0은 점수 계산 검사일 뿐이다. 실제 ASR 성능 결과로 쓰지 않았다.** 콜백 대체 검사는 실제 마이크·드라이버 녹음을 대신하지 않는다.

## 미검증 — 측정치를 만들지 않음

- 모든 모델의 실제 영어/한국어 WER, CER, 전문 용어 오류, 발언 누락률
- VAD ON/OFF가 실제 작은 목소리에 미치는 영향
- M2 Air 8GB/16GB 메모리 적합성, 발열/thermal throttling, 배터리, GPU 부하
- MLX Whisper 및 Qwen 실추론, 모델 설치·Mac 의존성 조합
- Ollama 실번역·요약·질문 품질과 처리 지연, 장시간 처리율
- macOS 마이크 권한 및 BlackHole 실제 채널 라우팅
- 실제 10/30/60분 마이크/시스템 녹음 연속성
- .app 빌드·서명·공증·Gatekeeper·frozen multiprocessing
- 회의 전체 검색/RAG, 화자 분리, 문장/단어 timestamp, 자동 고정밀 최종 보정
- 클라우드 GPT/Claude 연동 및 API Keychain 저장 (미구현)

이 버전은 설계만 있는 문서나 가상 녹음 화면이 아니라 실제 저장/작업/GUI 코드를 갖춘 소스 MVP다. 그러나 위 실기기 검증을 통과하기 전에는 “일상 연구회의에서 검증된 안정 제품”이라고 부를 수 없다. 다음 실행 우선순위는 Mac에서 설치 → 2분 입력/전사/번역 시험 → 동일 10분 음원 모델 비교 → 30/60분 동시 처리 시험이다. 상세 절차는 `MAC_VALIDATION.md`에 있다.
