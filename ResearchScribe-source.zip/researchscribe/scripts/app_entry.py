import multiprocessing
if __name__ == '__main__':
    multiprocessing.freeze_support()
    from researchscribe.gui import main
    main()
