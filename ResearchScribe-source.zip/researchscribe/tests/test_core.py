import json
import tempfile
import unittest
import wave
from pathlib import Path
import numpy as np
from researchscribe.core import Config, create_session, connect, plan, dedup, read_audio, export_session, duration
from researchscribe.asr import work_once
from researchscribe.ai import validate_claims

class RecorderTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.path=create_session(Config(),16000,self.root)
    def tearDown(self): self.temp.cleanup()
    def audio(self, seconds):
        with (self.path/'audio.pcm').open('ab') as f: f.write(np.zeros(round(16000*seconds),dtype='<i2').tobytes())
    def rows(self):
        with connect(self.path) as db: return db.execute('SELECT * FROM chunks ORDER BY start').fetchall()
    def test_boundary_coverage_and_idempotent_recovery(self):
        for seconds in [0.2,9.8,2,10,1.25]:
            self.audio(seconds); plan(self.path)
        plan(self.path,complete=True); first=[(r['start'],r['end']) for r in self.rows()]
        plan(self.path,complete=True)
        self.assertEqual(first,[(r['start'],r['end']) for r in self.rows()])
        self.assertEqual(first[0][0],0); self.assertEqual(first[-1][1],duration(self.path))
        for a,b in zip(first,first[1:]): self.assertLessEqual(b[0],a[1])
    def test_short_last_window(self):
        self.audio(.25); plan(self.path); self.assertEqual(len(self.rows()),0)
        plan(self.path,complete=True); self.assertEqual(len(self.rows()),1)
    def test_raw_preserved_overlap_only_display(self):
        self.audio(23); plan(self.path,complete=True)
        class Model:
            def transcribe(self,a): return 'Atomic reconstruction uses diffusion models'
        while work_once(self.path,Model()): pass
        rows=self.rows(); self.assertTrue(all(r['raw']=='Atomic reconstruction uses diffusion models' for r in rows))
        self.assertEqual(rows[0]['text'],rows[0]['raw']); self.assertEqual(rows[1]['text'],'')
    def test_retry_persists_and_finishes_failed(self):
        self.audio(1); plan(self.path,complete=True)
        class Failure:
            def transcribe(self,a): raise RuntimeError('deliberate test')
        for i in range(3): self.assertTrue(work_once(self.path,Failure()))
        self.assertFalse(work_once(self.path,Failure()))
        row=self.rows()[0]; self.assertEqual(row['attempts'],3); self.assertEqual(row['status'],'failed')
        self.assertEqual(duration(self.path),1)
    def test_export_and_crash_partial_sample(self):
        self.audio(1)
        with (self.path/'audio.pcm').open('ab') as f: f.write(b'X')
        out=self.root/'export'; export_session(self.path,out)
        with wave.open(str(out/'recording.wav')) as w: self.assertEqual(w.getnframes(),16000)
        self.assertEqual(len(read_audio(self.path,0,1)),16000)
        self.assertTrue((out/'notes.md').is_file())
    def test_dedup_conservative(self):
        self.assertEqual(dedup('it is very important','very important result'),'very important result')
        self.assertEqual(dedup('use the diffusion model','the diffusion model improves quality'),'improves quality')
    def test_invented_quote_rejected(self):
        sources=[{'id':1,'text':'Input is noisy STEM.'}]
        result=json.dumps({'claims':[{'source_id':1,'text':'입력','quote':'noisy STEM'},
            {'source_id':1,'text':'조작','quote':'Accuracy is 99%'},{'source_id':99,'text':'조작','quote':'noisy STEM'}]})
        self.assertEqual(len(validate_claims(result,sources)),1)
    def test_live_final_independent(self):
        self.audio(20); plan(self.path,complete=True); plan(self.path,'final',True)
        with connect(self.path) as db:
            self.assertEqual(db.execute('SELECT COUNT(DISTINCT pass) FROM chunks').fetchone()[0],2)
    def test_vad_off_never_skips_silence(self):
        self.audio(1); plan(self.path,complete=True)
        class Model:
            calls=0
            def transcribe(self,a): self.calls+=1; return ''
        m=Model(); work_once(self.path,m); self.assertEqual(m.calls,1)
    def test_resample_48000(self):
        other=create_session(Config(),48000,self.root)
        (other/'audio.pcm').write_bytes(np.zeros(48000,dtype='<i2').tobytes())
        self.assertEqual(read_audio(other,0,1).shape,(16000,))
    def test_invalid_overlap(self):
        with self.assertRaises(ValueError): Config(overlap=10).validate()

if __name__=='__main__': unittest.main()

class CaptureTests(unittest.TestCase):
    def test_capture_writer_drains_and_preserves_stereo(self):
        import threading
        from unittest.mock import patch
        from types import SimpleNamespace
        from researchscribe.capture import capture
        with tempfile.TemporaryDirectory() as temp:
            path=create_session(Config(),16000,temp,channels=2)
            stop=threading.Event(); pause=threading.Event()
            data=np.arange(16000,dtype='<i2').tobytes()
            class Stream:
                def __init__(self,**kwargs): self.callback=kwargs['callback']
                def __enter__(self):
                    for _ in range(4): self.callback(data,4000,None,None)
                    stop.set(); return self
                def __exit__(self,*args): pass
            with patch.dict('sys.modules',{'sounddevice':SimpleNamespace(RawInputStream=Stream)}):
                capture(path,None,stop,pause)
            self.assertEqual((path/'audio.pcm').read_bytes(),data*4)
            self.assertEqual(duration(path),2)
            self.assertEqual(len(read_audio(path,0,2)),32000)
            self.assertEqual(json.loads((path/'capture.json').read_text())['state'],'stopped')
    def test_cloud_model_rejected_before_request(self):
        from researchscribe.ai import LocalAI
        with self.assertRaises(ValueError): LocalAI('qwen3:cloud')
