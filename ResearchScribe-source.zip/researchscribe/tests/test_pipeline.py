import argparse
import json
import tempfile
import unittest
import wave
from pathlib import Path
from unittest.mock import patch
import numpy as np
from researchscribe.core import Config, create_session, plan, connect, config_for, atomic_json
from researchscribe.asr import work_once
from researchscribe.cli import benchmark

class PipelineTests(unittest.TestCase):
    def test_vad_on_keeps_audio_even_when_skipped(self):
        with tempfile.TemporaryDirectory() as temp:
            p=create_session(Config(vad=True),16000,temp)
            audio=np.zeros(16000,dtype='<i2').tobytes(); (p/'audio.pcm').write_bytes(audio)
            plan(p,complete=True)
            class Model:
                def transcribe(self,a): raise AssertionError('silence should be skipped')
            self.assertTrue(work_once(p,Model()))
            with connect(p) as db:
                self.assertEqual(db.execute('SELECT status FROM chunks').fetchone()[0],'done')
            self.assertEqual((p/'audio.pcm').read_bytes(),audio)
    def test_benchmark_metrics_with_controlled_hypothesis(self):
        # Verifies scoring/output logic only. Not a speech recognition benchmark.
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); audio=root/'test.wav'; ref=root/'ref.txt'; ref.write_text('Input is noisy STEM')
            with wave.open(str(audio),'wb') as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(np.zeros(16000,dtype='<i2').tobytes())
            class ControlledRecognizer:
                def __init__(self,c): pass
                def transcribe(self,a): return 'Input is noisy STEM'
            args=argparse.Namespace(audio=str(audio),reference=str(ref),model='small',vad=False,vad_mode=0,chunk=12,overlap=2,output=str(root/'out'))
            with patch('researchscribe.cli.Recognizer',ControlledRecognizer): benchmark(args)
            result=json.loads(next((root/'out').glob('*/benchmark.json')).read_text())
            self.assertTrue(result['valid']); self.assertEqual(result['wer'],0); self.assertEqual(result['cer'],0)
    def test_benchmark_failure_not_scored(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); audio=root/'test.wav'; ref=root/'ref.txt'; ref.write_text('word')
            with wave.open(str(audio),'wb') as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(np.zeros(16000,dtype='<i2').tobytes())
            class BrokenRecognizer:
                def __init__(self,c): pass
                def transcribe(self,a): raise RuntimeError('controlled failure')
            args=argparse.Namespace(audio=str(audio),reference=str(ref),model='small',vad=False,vad_mode=0,chunk=12,overlap=2,output=str(root/'out'))
            with patch('researchscribe.cli.Recognizer',BrokenRecognizer), self.assertRaises(SystemExit): benchmark(args)
            result=json.loads(next((root/'out').glob('*/benchmark.json')).read_text())
            self.assertFalse(result['valid']); self.assertNotIn('wer',result)
