# 기술 조사·아키텍처 — 2026-11-10

## 선정 결론

Python + PySide6 + sounddevice/PortAudio + 별도 녹음 프로세스 + SQLite WAL + MLX ASR + Ollama 로컬 LLM을 구현했다. **성능 우승 모델은 선정하지 않았다.** M2 Air, 정답이 있는 강연 음원, 실제 마이크를 사용할 수 없는 환경이므로 정확도·전문 용어 오류·긴 강의 누락·8GB/16GB 적합성은 측정 대기다. Whisper small은 처음 설치할 후보이고 turbo/Qwen은 같은 하네스에서 비교할 후보다.

공개 벤치마크의 서로 다른 데이터셋·장치 수치를 합쳐 M2 실시간 성능표로 만들지 않았다. 이 프로젝트의 WER/CER/메모리/RTF 실측값은 아직 없다. 원문이 언급하는 지원 기능과 이 프로그램에서 실제 검증한 기능은 다르다.

## 공식 자료에서 확인한 구현 지원

| 후보 | 확인한 근거/역할 | 영어 정확도·전문 용어·긴 강의 누락 | M2 지연/RAM | 8GB / 16GB 판단 |
|---|---|---|---|---|
| Whisper small / MLX | MLX Whisper API와 small 변환 체크포인트가 공개됨. 초기 설정 | 같은 강연으로 미측정 | 미측정 | 양쪽 초기 시험 후보, 실행 보장 아님 |
| Whisper large-v3-turbo / MLX | 변환 모델 카드와 `transcribe(path_or_hf_repo=...)` 공개 | 미측정 | 미측정; 모델 파일 크기는 실행 RAM과 다름 | 단독/번역 동시 각각 측정 후 결정 |
| Whisper large-v3 / MLX | 모델 카드에 mlx-whisper 사용법 있음 | 미측정 | 미측정 | 16GB에서도 장시간 동시 실행은 별도 검증 |
| Qwen3-ASR 0.6B / MLX | Qwen 공식 ASR + 커뮤니티 MLX 포팅·8bit 체크포인트 | 미측정 | 미측정 | 경량 비교 후보; 파라미터 수만으로 RAM 예측하지 않음 |
| Qwen3-ASR 1.7B / MLX | 동일 구현의 1.7B 지원 | 미측정 | 미측정 | 16GB 비교 후보, 8GB는 단독부터 시험 |
| whisper.cpp | 프로젝트가 Apple Silicon/Metal/Accelerate/Core ML 지원을 명시 | 이 앱에서 미측정 | 미측정 | Python MLX 대안. 이번 버전 어댑터는 미구현 |
| Parakeet TDT 0.6B v3 | NVIDIA 모델 카드의 다국어 확장은 유럽 언어 중심 | 한국어 포함 요구와 맞지 않아 기본 후보 제외 | 미측정 | 영어 전용 후속 비교 후보 |

Qwen의 공식 Python 예시는 Transformers/vLLM 기반이다. 이 프로젝트는 그것을 M2 최적화 구현이라고 부르지 않고 **별도 커뮤니티 MLX 포팅**을 사용한다. 0.4.8 배포 wheel의 `mlx_audio.stt.load`, `generate(audio=np.ndarray, language, system_prompt, max_tokens)` 서명을 확인했고 MLX 실행은 하지 않았다. Whisper는 공개 MLX Python API와 체크포인트 이름을 확인했다.

오프라인은 설치/가중치 다운로드 완료 후를 뜻한다. ASR 작업 프로세스는 HF/Transformers offline 환경변수를 설정한다. 모델이 없으면 실패를 기록하고 원음 녹음은 계속한다. 모델 파일이 존재하는 것과 import/Metal 추론이 되는 것은 구분해야 한다.

## 로컬 번역·요약

Qwen3 1.7B + Ollama HTTP API를 초기 후보로 구현했다. 같은 모델을 번역·요약에 사용해 여러 LLM 상주를 피한다. `think:false`, 4096 context, 생성 한도 1536, temperature 0, `keep_alive:0`으로 요청한다. 이는 메모리 반환을 우선하는 설정이며 청크마다 모델 로딩 지연이 늘 수 있다. 실측 후 keep_alive와 모델 크기를 조정해야 한다. 성능 측정 없이 “실시간 번역 가능”이라 주장하지 않는다.

Ollama 공식 API의 nonstream 응답을 사용한다. 두 이전 청크는 번역 문맥으로만 주고 현재 청크만 번역하도록 요청한다. 이 방식도 한/영 자연스러움·수치 보존을 보장하지 않는다. 요약은 새 청크 최대 24개와 이전 요약의 최근 40개 항목을 참조해 인용 항목을 누적한다. 기존 항목의 의미 통합·결정 번복을 완전히 해결한 요약 엔진은 아니며, 정정 발언 역시 새로운 근거로 보존한다.

GPT·Claude는 유료 API 비용과 외부 전송 동의/키 관리를 함께 구현해야 하므로 이번 MVP에서 제외했다. 로컬 Ollama 요청도 cloud 태그를 허용하지 않고, 원격 모델 메타데이터를 검사한다. 서버는 공식 `OLLAMA_NO_CLOUD=1` 옵션으로 실행한다.

## UI 프레임워크 비교

| 방식 | 장점 | 비용/제약 | 선택 |
|---|---|---|---|
| PySide6 | Python ASR/테스트 도구 재사용, 실제 데스크톱 위젯, 여러 패널·테이블·스레드 지원 | Apple 권한·서명·PyInstaller/Metal 번들 별도 검증, 네이티브 SwiftUI보다 큰 배포물 | MVP |
| SwiftUI | macOS 권한/오디오/ScreenCaptureKit 네이티브 통합에 유리 | Swift 경험 및 Python 모델과 IPC/네이티브 포팅 필요 | 후속 캡처 helper 후보 |
| 웹/브라우저 GUI | 빠른 UI 구현 | 마이크/시스템 캡처·백그라운드 수명·보안 범위 추가 설계 | 이번 목적에 미선택 |

위 표의 개발비용 평가는 아키텍처 판단이며 실측 성능 비교가 아니다.

## 기존 제품에서 가져온 사용 원칙

- Alt 공식 사이트의 로컬 보관·오프라인·내보내기 지향을 참고했다. 누락 원인이 VAD인지 마이크인지 모델인지 확인할 자료가 없으므로 Alt 내부 버그라고 단정하지 않는다.
- Granola 공식 사이트의 회의 중 노트와 후속 질문 흐름을 참고했다. 제품의 비공개 인식/요약 알고리즘을 재현했다고 주장하지 않는다.
- CLOVA Note 공식 도움말의 음성과 기록을 오가며 확인하는 흐름을 참고해 청크 ID·원음 듣기·내보내기를 넣었다. 북마크/하이라이트는 아직 미구현이다.
- 화면 배치와 코드는 독자적으로 작성했다.

## 데이터 경로와 실패 격리

1. PortAudio callback: 250ms PCM 블록을 최대 20초짜리 bounded queue에 복사한다. AI·DB·번역은 callback에서 호출하지 않는다.
2. 녹음 프로세스: queue를 파일로 쓰고 매초 fsync. 권한/디스크/장치 오류·overflow는 경고와 이벤트를 남긴다. 큐가 넘치면 중지하며 누락을 숨기지 않는다.
3. ASR 프로세스: 파일 길이로 12초/overlap 2초 작업을 계획하고 SQLite에 저장한다. 전체 녹음은 메모리에 올리지 않는다. 끝난 파일은 마지막 부분 청크도 처리한다.
4. VAD OFF가 기본이다. 선택 WebRTC 모드는 30ms 프레임 하나라도 speech면 전체 창을 유지한다. 무음으로 판정한 창도 원음/작업 기록을 보존한다. 조용한 발언을 잘못 제거할 수 있으므로 실제 음성 A/B가 필수다.
5. 중복 병합은 겹치는 창에서 3단어 이상 정확히 일치하는 suffix/prefix에 한해 **표시문만** 처리한다. 정렬 없는 휴리스틱이라 과병합·중복 잔존이 가능하며 `raw`는 보존한다. 한국어 띄어쓰기 차이도 한계다.
6. 번역·요약 프로세스: ASR와 독립, 실패 3회 후 번역 실패 표시. 요약은 주기마다 재시도. 인용 ID와 exact substring 검사, 원문 수정 시 stale 응답 폐기.
7. GUI: 최근 300개 청크/최근 150개 요약만 표시하고 전체 기록은 DB/내보내기에 보존한다. 질문은 최근 32청크만 검색한다.
8. 강제 종료 후: 원음 파일로 남은 구간을 계획하고 running 작업을 pending으로 바꾼다. 전원이 끊기면 마지막 fsync 이후 샘플까지 보장할 수는 없다.

별도 프로세스는 모델 예외와 UI 멈춤을 격리하지만 시스템 전체 OOM, 디스크 고갈, OS/드라이버 dropout을 방지하지는 못한다. 현장 마이크 자체가 발언을 충분히 담지 못하면 전사기가 복원할 수 없다. 최종 재전사도 같은 원음에 대한 재처리이며 원음에 없는 발언을 채워넣는 보정은 수행하지 않는다.

## 공식 출처

확인일 2026-11-10. 링크는 지원 상태의 근거이며 이 프로그램의 M2 벤치마크 근거가 아니다.

- Qwen 공식: https://github.com/QwenLM/Qwen3-ASR
- Qwen 기술 보고서: https://arxiv.org/abs/2601.21337
- MLX Qwen 구현: https://github.com/Neywa-Labs/mlx-audio/blob/main/mlx_audio/stt/models/qwen3_asr/README.md
- 검토한 배포 wheel: `mlx_audio-0.4.8-py3-none-any.whl` (코드/API 정적 확인)
- MLX Whisper: https://github.com/ml-explore/mlx-examples/blob/main/whisper/README.md
- small: https://huggingface.co/mlx-community/whisper-small-mlx
- turbo: https://huggingface.co/mlx-community/whisper-large-v3-turbo
- large: https://huggingface.co/mlx-community/whisper-large-v3-mlx
- whisper.cpp: https://github.com/ggml-org/whisper.cpp
- Parakeet: https://huggingface.co/nvidia/parakeet-tdt-0.6b-v3
- Ollama API: https://docs.ollama.com/api/chat
- 로컬 모델: https://ollama.com/library/qwen3
- Cloud OFF 옵션: https://github.com/ollama/ollama/blob/main/envconfig/config.go
- WebRTC VAD: https://github.com/wiseman/py-webrtcvad
- BlackHole: https://github.com/ExistentialAudio/BlackHole
- Apple 캡처: https://developer.apple.com/documentation/screencapturekit/capturing-screen-content-in-macos
- Alt: https://altalt.io/en/
- Granola: https://www.granola.ai/
- CLOVA Note 공식 도움말: https://help.naver.com/service/24269/contents/12842?lang=ko&osType=PC
