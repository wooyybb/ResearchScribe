import argparse
import hashlib
import json
import multiprocessing as mp
import platform
import threading
import time
import wave
from pathlib import Path
from .core import Config, create_session, connect, atomic_json, duration, plan, export_session
from .asr import Recognizer, work_once, run_asr

MODELS={
 'small':('whisper','mlx-community/whisper-small-mlx'),
 'turbo':('whisper','mlx-community/whisper-large-v3-turbo'),
 'large':('whisper','mlx-community/whisper-large-v3-mlx'),
 'qwen06':('qwen','mlx-community/Qwen3-ASR-0.6B-8bit'),
 'qwen17':('qwen','mlx-community/Qwen3-ASR-1.7B-8bit')}

def import_wav(source, config, root=None):
    with wave.open(str(source),'rb') as w:
        if (w.getnchannels(),w.getsampwidth(),w.getframerate())!=(1,2,16000):
            raise ValueError('Require mono PCM16 16000 Hz WAV. Convert with ffmpeg; see README.')
        path=create_session(config,16000,root)
        with (path/'audio.pcm').open('wb') as out:
            while block:=w.readframes(16000*10): out.write(block)
    atomic_json(path/'capture.json',{'frames':int(duration(path)*16000),'state':'imported','rms':0})
    return path

def benchmark(args):
    import psutil
    from jiwer import process_words, cer
    backend,model=MODELS[args.model]
    config=Config(backend=backend,model=model,vad=args.vad,vad_mode=args.vad_mode,chunk=args.chunk,overlap=args.overlap,ai_enabled=False)
    path=import_wav(args.audio,config,args.output)
    reference=Path(args.reference).read_text().strip() if args.reference else None
    with open(args.audio,'rb') as f: audio_hash=hashlib.file_digest(f,'sha256').hexdigest()
    measurements=[]; quit=threading.Event(); process=psutil.Process(); process.cpu_percent()
    def sample():
        while not quit.wait(.1):
            measurements.append({'rss':process.memory_info().rss,'cpu':process.cpu_percent()})
    sampler=threading.Thread(target=sample,daemon=True); sampler.start()
    start=time.monotonic()
    try:
        recognizer=Recognizer(config); loaded=time.monotonic()
        plan(path,'benchmark',True)
        while work_once(path,recognizer,'benchmark'): pass
    finally: quit.set(); sampler.join()
    elapsed=time.monotonic()-start
    with connect(path) as db:
        rows=[dict(r) for r in db.execute("SELECT * FROM chunks WHERE pass='benchmark' ORDER BY start")]
    text=' '.join(r['text'] for r in rows)
    failed=[r['id'] for r in rows if r['status']!='done']
    result={'valid':not failed,'failed_ids':failed,'model':args.model,'config':config.__dict__,
            'platform':platform.platform(),'machine':platform.machine(),
            'audio_sha256':audio_hash,
            'reference_sha256':hashlib.sha256(reference.encode()).hexdigest() if reference is not None else None,
            'audio_seconds':duration(path),'wall_seconds_including_load':elapsed,
            'recognizer_constructor_seconds':loaded-start,'rtf_including_load':elapsed/max(duration(path),.001),
            'peak_sampled_process_rss_bytes':max([m['rss'] for m in measurements],default=None),
            'peak_sampled_cpu_percent':max([m['cpu'] for m in measurements],default=None),
            'chunk_inference_seconds':[r['seconds'] for r in rows],
            'hypothesis':text,'metrics_scope':'offline ASR only; RTF is not capture-to-display latency; RSS excludes Metal allocations and Ollama',
            'gpu_memory':'unmeasured','speech_omission_rate':'unmeasured; requires timestamped human utterance annotations',
            'translation_latency':'unmeasured','summary_factual_accuracy':'unmeasured'}
    if reference is not None and not failed:
        # Same deterministic whitespace/case normalization for every model.
        ref=' '.join(reference.lower().split()); hyp=' '.join(text.lower().split())
        m=process_words(ref,hyp)
        result.update(wer=m.wer,cer=cer(ref,hyp),deletions=m.deletions,
            deletion_rate=m.deletions/max(1,len(ref.split())),substitutions=m.substitutions,insertions=m.insertions,
            normalization='lowercase and whitespace only; Korean WER is space-delimited, report CER too')
    atomic_json(path/'benchmark.json',result); export_session(path,path/'export','benchmark')
    print(path/'benchmark.json')
    if failed: raise SystemExit(2)

def main():
    mp.freeze_support()
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='command',required=True)
    d=sub.add_parser('download'); d.add_argument('--model',choices=MODELS,default='small')
    b=sub.add_parser('benchmark'); b.add_argument('audio'); b.add_argument('--reference'); b.add_argument('--model',choices=MODELS,default='small')
    b.add_argument('--vad',action='store_true'); b.add_argument('--vad-mode',type=int,choices=range(4),default=0); b.add_argument('--chunk',type=float,default=12); b.add_argument('--overlap',type=float,default=2); b.add_argument('--output',default='benchmarks')
    r=sub.add_parser('recover'); r.add_argument('session'); r.add_argument('--pass-name',default='live')
    e=sub.add_parser('export'); e.add_argument('session'); e.add_argument('destination'); e.add_argument('--pass-name',default='live')
    a=p.parse_args()
    if a.command=='download':
        from huggingface_hub import snapshot_download
        print(snapshot_download(MODELS[a.model][1]))
    elif a.command=='benchmark': benchmark(a)
    elif a.command=='recover':
        ctx=mp.get_context('spawn'); finish=ctx.Event(); finish.set(); cancel=ctx.Event()
        run_asr(a.session,finish,cancel,a.pass_name)
    elif a.command=='export': export_session(a.session,a.destination,a.pass_name)

if __name__=='__main__': main()
