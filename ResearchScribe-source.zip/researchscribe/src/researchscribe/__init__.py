"""ResearchScribe: recorder-first, local-first research notes."""
