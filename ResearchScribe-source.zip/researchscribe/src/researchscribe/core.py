from __future__ import annotations
import json
import os
import sqlite3
import time
import wave
from pathlib import Path
from dataclasses import dataclass, asdict

ROOT = Path.home() / 'Library/Application Support/ResearchScribe'

@dataclass
class Config:
    backend: str = 'whisper'
    model: str = 'mlx-community/whisper-small-mlx'
    language: str = 'en'
    chunk: float = 12
    overlap: float = 2
    vad: bool = False
    vad_mode: int = 0
    llm_model: str = 'qwen3:1.7b'
    mode: str = 'lecture'
    terms: str = 'Diffusion, Transformer, STEM, TEM, Tomography, Atomic Reconstruction'
    ai_enabled: bool = True
    def validate(self):
        if not (2 <= self.chunk <= 30 and 0 <= self.overlap < self.chunk / 2):
            raise ValueError('chunk: 2–30 sec; overlap < half chunk required')
        if self.vad_mode not in range(4): raise ValueError('VAD mode must be 0–3')
        if self.backend not in ('whisper', 'qwen'):
            raise ValueError('Unknown ASR backend')
        return self

def atomic_json(path, value):
    path = Path(path)
    temp = path.with_suffix('.tmp')
    with temp.open('w') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(temp, path)

def connect(path):
    db = sqlite3.connect(Path(path) / 'session.sqlite', timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=FULL')
    db.executescript('''
    CREATE TABLE IF NOT EXISTS chunks (
      id INTEGER PRIMARY KEY, pass TEXT, start REAL, end REAL,
      status TEXT DEFAULT 'pending', attempts INTEGER DEFAULT 0,
      raw TEXT DEFAULT '', text TEXT DEFAULT '', edited TEXT,
      translation TEXT, translation_status TEXT DEFAULT 'pending',
      translation_attempts INTEGER DEFAULT 0, error TEXT,
      seconds REAL, UNIQUE(pass,start));
    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY, kind TEXT, content TEXT, created REAL);
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY, at REAL, kind TEXT, detail TEXT);
    ''')
    return db

def event(path, kind, detail):
    with connect(path) as db:
        db.execute('INSERT INTO events(at,kind,detail) VALUES(?,?,?)', (time.time(),kind,str(detail)))

def create_session(config, rate=48000, root=None, channels=1):
    import uuid
    config.validate()
    root = Path(root or ROOT)
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = root / (time.strftime('%Y%m%d-%H%M%S')+'-'+uuid.uuid4().hex[:6])
    path.mkdir(mode=0o700)
    atomic_json(path/'config.json', asdict(config))
    atomic_json(path/'audio.json', {'rate':rate, 'channels':channels, 'dtype':'<i2'})
    atomic_json(path/'capture.json', {'frames':0,'state':'ready','rms':0})
    (path/'audio.pcm').touch(mode=0o600)
    connect(path).close()
    return path

def config_for(path):
    return Config(**json.loads((Path(path)/'config.json').read_text())).validate()

def audio_info(path):
    return json.loads((Path(path)/'audio.json').read_text())

def duration(path):
    return (Path(path)/'audio.pcm').stat().st_size // (2 * audio_info(path)['channels']) / audio_info(path)['rate']

def plan(path, pass_name='live', complete=False):
    """Disk-backed scheduling. Every sample is covered; overlap never cuts audio."""
    c = config_for(path); rate = audio_info(path)['rate']
    total_frames = (Path(path)/'audio.pcm').stat().st_size // (2*audio_info(path)['channels'])
    step = round((c.chunk-c.overlap)*rate); size=round(c.chunk*rate)
    with connect(path) as db:
        last = db.execute('SELECT MAX(start) FROM chunks WHERE pass=?',(pass_name,)).fetchone()[0]
        start = 0 if last is None else round(last*rate)+step
        while start < total_frames:
            end = min(start+size,total_frames)
            if end-start < size and not complete: break
            # Do not create an overlap-only tail already fully covered.
            prev = db.execute('SELECT MAX(end) FROM chunks WHERE pass=?',(pass_name,)).fetchone()[0]
            if prev is not None and end/rate <= prev: break
            db.execute('INSERT OR IGNORE INTO chunks(pass,start,end) VALUES(?,?,?)',
                       (pass_name,start/rate,end/rate))
            start += step

def read_audio(path, start, end):
    import numpy as np
    from scipy.signal import resample_poly
    from math import gcd
    rate=audio_info(path)['rate']; channels=audio_info(path)['channels']; a=round(start*rate); b=round(end*rate)
    with (Path(path)/'audio.pcm').open('rb') as f:
        f.seek(a*2*channels); data=f.read((b-a)*2*channels)
    if len(data)!=(b-a)*2*channels: raise ValueError('Audio range truncated; original may have been interrupted')
    x=np.frombuffer(data,dtype='<i2').reshape(-1,channels).astype(np.float32).mean(axis=1)/32768
    if rate != 16000:
        g=gcd(rate,16000); x=resample_poly(x,16000//g,rate//g).astype(np.float32)
    return x

def dedup(previous, current):
    """Conservative display-only suffix merge. Raw hypotheses always remain."""
    import re
    a=previous.split(); b=current.split()
    norm=lambda s: re.sub(r'[^\w]','',s).casefold()
    for n in range(min(35,len(a),len(b)),2,-1):
        if [norm(s) for s in a[-n:]] == [norm(s) for s in b[:n]]:
            return ' '.join(b[n:])
    return current

def export_session(path, destination, pass_name='live'):
    import shutil
    destination=Path(destination); destination.mkdir(parents=True,exist_ok=True)
    # Snapshot SQLite consistently even while workers are writing.
    with connect(path) as db:
        rows=[dict(r) for r in db.execute('SELECT * FROM chunks WHERE pass=? ORDER BY start',(pass_name,))]
        notes=[dict(r) for r in db.execute('SELECT * FROM notes ORDER BY id')]
        events=[dict(r) for r in db.execute('SELECT * FROM events ORDER BY id')]
    atomic_json(destination/'transcript.json', {'chunks':rows,'notes':notes,'events':events})
    lines=['# ResearchScribe — '+pass_name, '타임스탬프는 녹음된 오디오 기준. ASR·번역·요약은 검토가 필요합니다.','']
    for r in rows:
        lines.extend([f"[{r['start']:.2f}–{r['end']:.2f}] #{r['id']} ({r['status']})",
                      r['edited'] if r['edited'] is not None else r['text'], r['translation'] or '번역 대기/실패',''])
    lines.extend(n['content'] for n in notes)
    (destination/'notes.md').write_text('\n'.join(lines))
    rate=audio_info(path)['rate']
    with wave.open(str(destination/'recording.wav'),'wb') as out:
        channels=audio_info(path)['channels']
        out.setnchannels(channels); out.setsampwidth(2); out.setframerate(rate)
        with (Path(path)/'audio.pcm').open('rb') as source:
            # Snapshot length, excluding incomplete sample on crash.
            framebytes=2*channels
            remaining=(Path(path)/'audio.pcm').stat().st_size//framebytes*framebytes
            while remaining:
                block=source.read(min(1024*1024,remaining))
                if not block: break
                out.writeframesraw(block); remaining-=len(block)
    for name in ('config.json','audio.json'):
        shutil.copy2(Path(path)/name,destination/name)
