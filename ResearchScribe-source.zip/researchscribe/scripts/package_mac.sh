#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ "$(uname -s)" == Darwin && "$(uname -m)" == arm64 ]] || exit 1
.venv/bin/python -m pip install -e '.[package]'
.venv/bin/pyinstaller ResearchScribe.spec --noconfirm
printf '\nUnsigned app created; signing, notarization, MLX dylibs and microphone permissions require target-Mac testing.\n'
