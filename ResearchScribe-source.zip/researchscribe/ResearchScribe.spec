# Experimental: build only on Apple Silicon. No bundled model weights.
from PyInstaller.utils.hooks import collect_all
from pathlib import Path
base=Path(SPECPATH)
datas=[]; binaries=[]; hidden=[]
for package in ['mlx_whisper','mlx_audio','mlx','sounddevice','scipy']:
    d,b,h=collect_all(package); datas+=d; binaries+=b; hidden+=h
a=Analysis([str(base/'scripts/app_entry.py')],pathex=[str(base/'src')],
           binaries=binaries,datas=datas,hiddenimports=hidden,excludes=['torch','tensorflow'])
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='ResearchScribe',console=False)
coll=COLLECT(exe,a.binaries,a.datas,name='ResearchScribe')
app=BUNDLE(coll,name='ResearchScribe.app',bundle_identifier='org.researchscribe.local',
           info_plist={'NSMicrophoneUsageDescription':'연구회의 및 강의 음성을 사용자 Mac에 녹음합니다.',
                       'NSHighResolutionCapable':True})
