import os
import time
from pathlib import Path
from .core import config_for, connect, plan, read_audio, dedup, event

class Recognizer:
    def __init__(self, config):
        # Downloads are a separate explicit operation. Recording inference is offline.
        os.environ['HF_HUB_OFFLINE']='1'
        os.environ['TRANSFORMERS_OFFLINE']='1'
        self.c=config; self.model=None
        if config.backend=='qwen':
            from mlx_audio.stt import load
            self.model=load(config.model)
    def transcribe(self, audio):
        if self.c.backend=='whisper':
            import mlx_whisper
            r=mlx_whisper.transcribe(audio,path_or_hf_repo=self.c.model,
                language=None if self.c.language=='auto' else self.c.language,
                initial_prompt=self.c.terms, condition_on_previous_text=False,
                temperature=0.0, verbose=False)
            return r['text'].strip()
        language={'en':'English','ko':'Korean','auto':None}[self.c.language]
        # MLX community implementation; adapter smoke test required on target Mac.
        kwargs={'audio':audio, 'max_tokens':1024, 'system_prompt':'Technical vocabulary: '+self.c.terms}
        if language: kwargs['language']=language
        r=self.model.generate(**kwargs)
        return r.text.strip()

def has_speech(audio, mode=0):
    import numpy as np
    import webrtcvad
    detector=webrtcvad.Vad(mode)
    samples=np.clip(audio*32768,-32768,32767).astype('<i2')
    # Conservative: one positive 30 ms frame keeps the ENTIRE window.
    for start in range(0,len(samples),480):
        frame=np.pad(samples[start:start+480],(0,max(0,480-len(samples[start:start+480]))))
        if detector.is_speech(frame.tobytes(),16000): return True
    return False

def work_once(path, recognizer, pass_name='live'):
    import numpy as np
    c=config_for(path)
    with connect(path) as db:
        row=db.execute("SELECT * FROM chunks WHERE pass=? AND status='pending' ORDER BY start LIMIT 1",(pass_name,)).fetchone()
        if row is None: return False
        db.execute("UPDATE chunks SET status='running',attempts=attempts+1 WHERE id=?",(row['id'],))
    begin=time.monotonic()
    try:
        audio=read_audio(path,row['start'],row['end'])
        # Optional conservative WebRTC VAD: no within-window trimming.
        skipped=c.vad and not has_speech(audio,c.vad_mode)
        raw='' if skipped else recognizer.transcribe(audio)
        with connect(path) as db:
            prev=db.execute("SELECT raw,end FROM chunks WHERE pass=? AND start<? AND status='done' ORDER BY start DESC LIMIT 1",(pass_name,row['start'])).fetchone()
            text=dedup(prev['raw'],raw) if prev and prev['end']>row['start'] else raw
            db.execute("UPDATE chunks SET status='done',raw=?,text=?,seconds=?,error=NULL,translation_status=? WHERE id=?",
                       (raw,text,time.monotonic()-begin,'pending' if text else 'empty',row['id']))
        if skipped: event(path,'experimental_vad_skip',row['id'])
    except Exception as e:
        with connect(path) as db:
            db.execute('UPDATE chunks SET status=?,error=? WHERE id=?',
                       ('pending' if row['attempts']<2 else 'failed',repr(e),row['id']))
        event(path,'asr_error',repr(e)); time.sleep(.5)
    return True

def run_asr(path, finish, cancel, pass_name='live'):
    import fcntl
    with (Path(path)/'asr.lock').open('a') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            event(path,'asr_start_error','Another ASR worker owns this session'); return
        _run_asr(path,finish,cancel,pass_name)

def _run_asr(path, finish, cancel, pass_name='live'):
    with connect(path) as db:
        db.execute("UPDATE chunks SET status='pending' WHERE status='running' AND pass=?",(pass_name,))
    try: recognizer=Recognizer(config_for(path))
    except Exception as e:
        event(path,'asr_start_error',repr(e)); return
    while not cancel.is_set():
        done=finish.is_set()
        plan(path,pass_name,complete=done)
        if not work_once(path,recognizer,pass_name):
            if done: return
            cancel.wait(.3)
