"""No model or GUI imports in the capture process."""
import json
import os
import queue
import time
from pathlib import Path
from .core import atomic_json, audio_info, event

def write_all(file, data):
    view=memoryview(data)
    while view:
        count=file.write(view)
        if not count: raise OSError('Audio disk write made no progress')
        view=view[count:]

def capture(path, device, stop, pause):
    import numpy as np
    import sounddevice as sd
    path=Path(path); rate=audio_info(path)['rate']; channels=audio_info(path)['channels']
    blocks=queue.Queue(maxsize=80)  # 20 seconds; explicit failure, never silent dropping.
    fault=[]; frames=0; rms=0.0; last=time.monotonic()
    def callback(indata, count, timing, status):
        if status: fault.append(str(status))
        if pause.is_set(): return
        try: blocks.put_nowait(bytes(indata))
        except queue.Full: fault.append('Audio writer queue overflow'); stop.set()
    state='stopped'
    try:
        with (path/'audio.pcm').open('ab',buffering=0) as f:
            with sd.RawInputStream(device=device, samplerate=rate, channels=channels,
                                   dtype='int16', blocksize=rate//4, callback=callback):
                while not stop.is_set():
                    try: data=blocks.get(timeout=.25)
                    except queue.Empty: data=b''
                    if data:
                        write_all(f,data); frames+=len(data)//(2*channels)
                        x=np.frombuffer(data,dtype='<i2').astype(float)/32768
                        rms=float(np.sqrt(np.mean(x*x)))
                    if fault:
                        event(path,'capture_fault','; '.join(fault)); fault.clear()
                        # Device overflow means completeness is unknown. Surface it.
                        atomic_json(path/'warning.json',{'message':'입력 유실 가능: events 확인','at':time.time()})
                    if time.monotonic()-last >= 1:
                        os.fsync(f.fileno()); last=time.monotonic()
                        atomic_json(path/'capture.json',{'frames':frames,'state':'paused' if pause.is_set() else 'recording','rms':rms})
            while not blocks.empty():
                data=blocks.get_nowait(); write_all(f,data); frames+=len(data)//(2*channels)
            os.fsync(f.fileno())
    except Exception as e:
        state='error'; event(path,'capture_error',repr(e))
        atomic_json(path/'warning.json',{'message':str(e),'at':time.time()})
    finally:
        if fault:
            event(path,'capture_fault','; '.join(fault))
            atomic_json(path/'warning.json',{'message':'입력 유실 가능: '+ '; '.join(fault),'at':time.time()})
        atomic_json(path/'capture.json',{'frames':frames,'state':state,'rms':0})
        event(path,'capture_end',state)
